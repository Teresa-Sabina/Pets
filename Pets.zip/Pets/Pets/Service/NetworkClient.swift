//
//  UIViewController.swift
//  Pets
//
//  Created by teresa sabina on 13/07/21.
//
import Foundation

struct NetworkClient {
    let baseUrl:String
    let path:String
    let params:String
    let method:String 
}
